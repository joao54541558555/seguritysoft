// src/models/usuario.js

const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database'); // Importa a conexão

const Funcionario = sequelize.define('Funcionario', {
    id_funcionario: {
    
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    cargo: {
        type: DataTypes.ENUM('Monitor', 'Tecnico', 'Administrativo'),
        allowNull: false
    },
    turno: {
        type: DataTypes.ENUM('Diurno', 'Noturno'),
        allowNull: false
    },
    email: {
        type: DataTypes.STRING(100),
        allowNull: false,
        unique: true
    },
    telefone: {
        type: DataTypes.STRING(20)
    },
    // CAMPO ESSENCIAL PARA AUTENTICAÇÃO
    senha: {
        type: DataTypes.STRING, // Armazena o hash da senha (bcrypt)
        allowNull: false
    }
}, {
    tableName: 'Funcionario',
    timestamps: false // A tabela não possui colunas createdAt/updatedAt
});

module.exports = Funcionario;