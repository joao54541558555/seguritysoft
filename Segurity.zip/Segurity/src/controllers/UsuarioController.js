// src/controllers/usuariocontroller.js

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Funcionario = require('../models/Usuario');

// Geração do token JWT (JSON Web Token)
const generateToken = (usuario) => {
    return jwt.sign(
        { id: usuario.id_funcionario, email: usuario.email, cargo: usuario.cargo },
        process.env.JWT_SECRET,
        { expiresIn: '1d' } // Token expira em 1 di a
    );
};

// 1. Registrar novo funcionário/usuário
exports.registrarFuncionario = async (req, res) => {
    const { nome, cargo, turno, email, telefone, senha } = req.body;

    try {
        // Criptografa a senha antes de salvar
        const salt = await bcrypt.genSalt(10);
        const senhaHashed = await bcrypt.hash(senha, salt);

        const funcionario = await Funcionario.create({
            nome,
            cargo: cargo || 'Monitor', // Define um padrão se não for fornecido
            turno: turno || 'Diurno', // Define um padrão se não for fornecido
            email,
            telefone,
            senha: senhaHashed
        });

        const token = generateToken(funcionario);
        res.status(201).json({ message: 'Usuário registrado', token, usuario: { nome, cargo } });

    } catch (error) {
        if (error.name === 'SequelizeUniqueConstraintError') {
            return res.status(400).json({ error: 'Este e-mail já está cadastrado.' });
        }
        console.error('Erro ao registrar:', error);
        res.status(500).json({ error: 'Erro interno ao registrar usuário.' });
    }
};

// 2. Logar funcionário/usuário
exports.loginFuncionario = async (req, res) => {
    const { email, senha } = req.body;

    try {
        const funcionario = await Funcionario.findOne({ where: { email } });
        if (!funcionario) {
            return res.status(404).json({ error: 'Credenciais inválidas.' });
        }

        // Compara a senha fornecida com o hash salvo no DB
        const isMatch = await bcrypt.compare(senha, funcionario.senha);
        if (!isMatch) {
            return res.status(400).json({ error: 'Credenciais inválidas.' });
        }

        const token = generateToken(funcionario);
        res.status(200).json({
            message: 'Login bem-sucedido',
            token,
            usuario: {
                id: funcionario.id_funcionario,
                nome: funcionario.nome,
                cargo: funcionario.cargo
            }
        });

    } catch (error) {
        console.error('Erro ao logar:', error);
        res.status(500).json({ error: 'Erro interno ao logar.' });
    }
};

// 3. Exemplo de rota protegida para obter dados do usuário logado
exports.getPerfil = async (req, res) => {
    // Os dados do usuário (id, email, cargo) estão em req.usuario, injetados pelo middleware
    res.json({
        message: 'Dados do usuário autenticado',
        usuario: req.usuario
    });
};