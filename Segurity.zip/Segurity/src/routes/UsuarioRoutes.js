// src/routes/usuarioroutes.js

const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/UsuarioController');
const verificarToken = require('../middlewares/authMiddleware'); // Importa o middleware

// Rotas de Autenticação
// POST /api/auth/register: Cria um novo usuário
router.post('/register', usuarioController.registrarFuncionario);

// POST /api/auth/login: Realiza o login e retorna o token
router.post('/login', usuarioController.loginFuncionario);

// Rota de exemplo que requer autenticação JWT para ser acessada
// GET /api/auth/perfil
router.get('/perfil', verificarToken, usuarioController.getPerfil);


module.exports = router;