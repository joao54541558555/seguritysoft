create database Securitysoft;
use Security;
CREATE TABLE Cliente (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefone VARCHAR(20),
    cpf_cnpj VARCHAR(20) UNIQUE,
    endereco_cobranca VARCHAR(150)
);

CREATE TABLE Local_Monitorado (
    id_local INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    endereco VARCHAR(150) NOT NULL,
    tipo_local ENUM('Residencial','Comercial','Industrial') NOT NULL,
    status_monitoramento ENUM('Ativo','Suspenso') DEFAULT 'Ativo',
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente)
);
CREATE TABLE Plano_Servico (
    id_plano INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    descricao TEXT,
    valor_mensal DECIMAL(10,2) NOT NULL,
    nivel_seguranca ENUM('Basico','Avancado','Premium') NOT NULL
);
CREATE TABLE Contrato (
    id_contrato INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_local INT NOT NULL,
    id_plano INT NOT NULL,
    data_inicio DATE NOT NULL,
    data_fim DATE,
    status ENUM('Ativo','Cancelado','Suspenso') DEFAULT 'Ativo',
    FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
    FOREIGN KEY (id_local) REFERENCES Local_Monitorado(id_local),
    FOREIGN KEY (id_plano) REFERENCES Plano_Servico(id_plano)
);
CREATE TABLE Equipamento (
    id_equipamento INT AUTO_INCREMENT PRIMARY KEY,
    id_local INT NOT NULL,
    tipo ENUM('Camera','Sensor','Alarme') NOT NULL,
    modelo VARCHAR(50),
    status ENUM('Ativo','Manutencao','Inativo') DEFAULT 'Ativo',
    FOREIGN KEY (id_local) REFERENCES Local_Monitorado(id_local)
);
CREATE TABLE Alerta (
    id_alerta INT AUTO_INCREMENT PRIMARY KEY,
    id_equipamento INT NOT NULL,
    data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    tipo_alerta ENUM('Movimento','Som','Falha_Energia','Invasao') NOT NULL,
    status ENUM('Pendente','Resolvido') DEFAULT 'Pendente',
    FOREIGN KEY (id_equipamento) REFERENCES Equipamento(id_equipamento)
);
CREATE TABLE Chamado_Autoridade (
    id_chamado INT AUTO_INCREMENT PRIMARY KEY,
    id_alerta INT NOT NULL,
    autoridade ENUM('Policia','Bombeiros') NOT NULL,
    data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Acionado','Concluido') DEFAULT 'Acionado',
    FOREIGN KEY (id_alerta) REFERENCES Alerta(id_alerta)
);
CREATE TABLE Pagamento (
    id_pagamento INT AUTO_INCREMENT PRIMARY KEY,
    id_contrato INT NOT NULL,
    data_pagamento DATE NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    metodo ENUM('Cartao','Boleto','Pix') NOT NULL,
    status ENUM('Pago','Pendente','Atrasado') DEFAULT 'Pendente',
    FOREIGN KEY (id_contrato) REFERENCES Contrato(id_contrato)
);
CREATE TABLE Funcionario (
    id_funcionario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cargo ENUM('Monitor','Tecnico','Administrativo') NOT NULL,
    turno ENUM('Diurno','Noturno') NOT NULL,
    email VARCHAR(100) UNIQUE,
    telefone VARCHAR(20)
);
CREATE TABLE Funcionario_Alerta (
    id_funcionario INT NOT NULL,
    id_alerta INT NOT NULL,
    PRIMARY KEY (id_funcionario, id_alerta),
    FOREIGN KEY (id_funcionario) REFERENCES Funcionario(id_funcionario),
    FOREIGN KEY (id_alerta) REFERENCES Alerta(id_alerta)
);
Create Table Vendas (
id_pagamento INT NOT NULL, 
id_contrato INT NOT NULL,
primary key (id_pagamento, id_contrato)
);