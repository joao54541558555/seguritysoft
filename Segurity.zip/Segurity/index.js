// index.js (Arquivo principal)

const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const { testConnection, sequelize } = require('../src/config/database'); 
const usuarioRoutes = require('./src/routes/UsuarioRoutes');
const Funcionario = require('./src/routes/UsuarioRoutes');

// Carregar variáveis de ambiente
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); // Permite requisições do frontend
app.use(express.json()); // Habilita o uso de JSON

// Funções de inicialização
async function startServer() {
    await testConnection(); // Testa a conexão com o DB
    
    // Opcional: Sincroniza o modelo Funcionario com a tabela no DB
    // Importante: Se a tabela já foi criada manualmente, remova ou comente esta linha
    await Funcionario.sync({ alter: true }); 

    // Rotas
    app.get('/', (req, res) => {
        res.send('API Segurity Soft está rodando! Acesse /api/auth para autenticação.');
    });

    // Rotas de Usuário (Autenticação)
    app.use('/api/auth', usuarioRoutes);

    // TODO: Adicionar rotas para as demais entidades (Clientes, Locais, etc.)

    // Iniciar o servidor
    app.listen(PORT, () => {
        console.log(`🚀 Servidor rodando na porta ${PORT}`);
    });
}

startServer();